package com.example.BJWA.thi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BjwaThiApplicationTests {

	@Test
	void contextLoads() {
	}

}
