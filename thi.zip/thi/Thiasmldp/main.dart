import 'dart:io';
import 'employee.dart';
import 'employee_manager.dart';

void main() {
  final manager = EmployeeManager();

  while (true) {
    print('===== MENU QUẢN LÝ NHÂN VIÊN =====');
    print('1. Nhập nhân viên mới');
    print('2. Xem danh sách tất cả nhân viên');
    print('3. Cập nhật thông tin nhân viên theo ID');
    print('4. Thoát');
    stdout.write('👉 Chọn chức năng: ');

    String? choice = stdin.readLineSync();

    switch (choice) {
      case '1':
        _addEmployee(manager);
        break;
      case '2':
        manager.showAllEmployee();
        break;
      case '3':
        _updateEmployee(manager);
        break;
      case '4':
        print('👋 Thoát chương trình.');
        return;
      default:
        print('⚠️ Lựa chọn không hợp lệ, vui lòng nhập lại.\n');
    }
  }
}

// Nhập Nv mới 
void _addEmployee(EmployeeManager manager) {
  stdout.write('Nhập ID: ');
  int id = int.parse(stdin.readLineSync()!);

  stdout.write('Nhập họ và tên: ');
  String name = stdin.readLineSync()!;

  stdout.write('Nhập ngày sinh: ');
  String dob = stdin.readLineSync()!;

  stdout.write('Nhập địa chỉ: ');
  String address = stdin.readLineSync()!;

  stdout.write('Nhập số điện thoại: ');
  String phone = stdin.readLineSync()!;

  var employee = Employee(id: id, name: name, dob: dob, address: address, phone: phone);
  manager.addNewEmployee(employee);
}

// Cập nhật Nv
void _updateEmployee(EmployeeManager manager) {
  stdout.write('Nhập ID nhân viên cần cập nhật: ');
  int id = int.parse(stdin.readLineSync()!);

  stdout.write('Nhập họ và tên mới: ');
  String name = stdin.readLineSync()!;

  stdout.write('Nhập ngày sinh mới: ');
  String dob = stdin.readLineSync()!;

  stdout.write('Nhập địa chỉ mới: ');
  String address = stdin.readLineSync()!;

  stdout.write('Nhập số điện thoại mới: ');
  String phone = stdin.readLineSync()!;

  manager.updateEmployee(id, name, dob, address, phone);
}
