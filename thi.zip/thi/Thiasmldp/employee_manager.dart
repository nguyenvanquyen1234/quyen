import 'employee.dart';

class EmployeeManager {
  final List<Employee> _employees = [];

  // Thêm Nv mới
  void addNewEmployee(Employee employee) {
    _employees.add(employee);
    print('✅ Nhân viên đã được thêm thành công!\n');
  }

  // Lấy danh sách tất cả nhân viên
  List<Employee> getAllEmployee() {
    return _employees;
  }

  // Cập nhật thông tin Nv theo ID
  bool updateEmployee(int id, String name, String dob, String address, String phone) {
    for (var emp in _employees) {
      if (emp.id == id) {
        emp.name = name;
        emp.dob = dob;
        emp.address = address;
        emp.phone = phone;
        print('✅ Nhân viên ID $id đã được cập nhật!\n');
        return true;
      }
    }
    print('⚠️ Không tìm thấy nhân viên có ID $id.\n');
    return false;
  }

  // Hiển thị tất cả Nv
  void showAllEmployee() {
    if (_employees.isEmpty) {
      print('📭 Chưa có nhân viên nào.\n');
    } else {
      print('\n===== DANH SÁCH NHÂN VIÊN =====');
      for (var emp in _employees) {
        print(emp);
      }
      print('==============================\n');
    }
  }
}
