class Employee {
  int id;
  String name;
  String dob; // ngày sinh
  String address;
  String phone;

  Employee({
    required this.id,
    required this.name,
    required this.dob,
    required this.address,
    required this.phone,
  });

  @override
  String toString() {
    return 'ID: $id, Họ tên: $name, Ngày sinh: $dob, Địa chỉ: $address, SĐT: $phone';
  }
}
