const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(bodyParser.urlencoded({ extended: true }));

// Class Order
class Order {
  constructor(Item, ItemName, Price, Currency, Quantity) {
    this.Item = Item;
    this.ItemName = ItemName;
    this.Price = Price;
    this.Currency = Currency;
    this.Quantity = Quantity;
  }
}

// Load orders từ file JSON
function loadOrders() {
  const data = fs.readFileSync("orders.json");
  return JSON.parse(data);
}

// Lưu orders vào file JSON
function saveOrders(orders) {
  fs.writeFileSync("orders.json", JSON.stringify(orders, null, 2));
}

// Trang chủ - hiển thị orders
app.get("/", (req, res) => {
  const orders = loadOrders();
  res.render("index", { orders });
});

// Form thêm order
app.get("/add", (req, res) => {
  res.render("add");
});

// Xử lý thêm order
app.post("/add", (req, res) => {
  const orders = loadOrders();
  const newOrder = new Order(
    req.body.Item,
    req.body.ItemName,
    parseFloat(req.body.Price),
    req.body.Currency,
    parseInt(req.body.Quantity)
  );
  orders.push(newOrder);
  saveOrders(orders);
  res.redirect("/");
});

// Form tìm kiếm
app.get("/search", (req, res) => {
  res.render("search", { result: null });
});

// Xử lý tìm kiếm
app.post("/search", (req, res) => {
  const orders = loadOrders();
  const keyword = req.body.ItemName.toLowerCase();
  const result = orders.filter(o =>
    o.ItemName.toLowerCase().includes(keyword)
  );
  res.render("search", { result });
});

// Chạy server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
